import tkinter as tk
from tkinter import simpledialog, messagebox, filedialog, scrolledtext
import pandas as pd
import random
import os
import uuid
import threading
import time
import webbrowser
import requests


class Administrator:

    def __init__(self, root):
        self.root = root
        self.root.title("Main Window")
        self.root.geometry("450x500")  # Slightly wider to accommodate labels

        # Core Data Storage
        self.target_dict = {}
        self.keys_iterator = None
        self.current_key = None
        self.results = {}

        # Employee scheduling state variables
        self.employee_names = []
        self.current_employee_index = 0
        self.save_folder = ""
        self.is_updating_single = False  # Track if we are modifying only one employee

        # OAuth / Stripe configuration & user state
        self.user_id = str(uuid.uuid4())
        self.backend_url = "http://127.0.0.1:8000"

        # Toplevel Window reference for classification
        self.class_win = None

        # Draw main dashboard interface
        self.start()

    def start(self):
        # Configure uniform weight for columns and rows to distribute space evenly
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        # Row 0, Column 0: Populate Employee
        btn_a = tk.Button(self.root, text="Populate employee", command=self.get_cards, padx=10, pady=5)
        btn_a.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        # Row 0, Column 1: Make Schedule
        btn_b = tk.Button(self.root, text="Make employee schedule", command=self.assign_schedule, padx=10, pady=5)
        btn_b.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

        # Row 1, Column 0: Check Schedule (Opens the new choice window)
        btn_c = tk.Button(self.root, text="Check on employee", command=self.check_on_schedule, padx=15, pady=5)
        btn_c.grid(row=1, column=0, padx=20, pady=20, sticky="nsew")

        # Row 1, Column 1: Purchase & Open Cloud Dictionary (Integrated Client)
        self.btn_d = tk.Button(self.root, text="Purchase & Open Dictionary", command=self.start_purchase_flow, padx=15,
                               pady=5, bg="green", fg="white")
        self.btn_d.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")

    def start_purchase_flow(self):
        """Disables the button and opens the Stripe gateway url on your local/cloud backend"""
        self.btn_d.config(state="disabled", text="Waiting for payment...", bg="orange")

        # Open default web browser to the server checkout redirection endpoint
        webbrowser.open(f"{self.backend_url}/buy/{self.user_id}")

        # Spin up background verification loop so the Tkinter UI doesn't freeze up
        threading.Thread(target=self.poll_for_auth, daemon=True).start()

    def poll_for_auth(self):
        """Asynchronously monitors the secure backend until a Stripe webhook validates the asset release"""
        while True:
            try:
                response = requests.get(f"{self.backend_url}/get-dictionary/{self.user_id}")
                if response.status_code == 200:
                    dictionary_payload = response.json()
                    # Hand data payload execution back to main loop to handle safe window updates
                    self.root.after(0, self.open_dictionary_window, dictionary_payload)
                    break
            except requests.exceptions.ConnectionError:
                # Backend server isn't running yet, or network dropped briefly. Rest and retry.
                pass

            time.sleep(2)

    def open_dictionary_window(self, data):
        """Re-enables dashboard controls and renders the retrieved data to an explicit UI view window"""
        self.btn_d.config(state="normal", text="Purchase & Open Dictionary", bg="green")

        new_window = tk.Toplevel(self.root)
        new_window.title("Purchased Cloud Dictionary Data")
        new_window.geometry("400x300")

        text_widget = tk.Text(new_window, wrap="word")
        text_widget.pack(fill="both", expand=True, padx=10, pady=10)

        # Display the custom payload dictionary cleanly
        for key, val in data.items():
            text_widget.insert(tk.END, f"【{key}】: {val}\n\n")

        text_widget.config(state="disabled")  # Set content frame to read-only

    def launch(self):
        """Creates or updates the independent classification window."""
        if not self.class_win or not self.class_win.winfo_exists():
            self.class_win = tk.Toplevel(self.root)
            self.class_win.geometry("350x200")

            self.label_prompt = tk.Label(self.class_win, text="Assign a value for:", font=("Arial", 11))
            self.label_prompt.pack(pady=5)

            self.label_key = tk.Label(self.class_win, text="", font=("Arial", 14, "bold"), fg='blue')
            self.label_key.pack(pady=5)

            self.button_frame = tk.Frame(self.class_win)
            self.button_frame.pack(pady=20)

            self.btn_yes = tk.Button(self.button_frame, text="Yes", width=10, bg="green", fg="white",
                                     command=lambda: self.process_input(1))
            self.btn_yes.pack(side=tk.LEFT, padx=10)
            self.btn_no = tk.Button(self.button_frame, text="No", width=10, bg="red", fg="white",
                                    command=lambda: self.process_input(0))
            self.btn_no.pack(side=tk.LEFT, padx=10)

        current_emp = self.employee_names[self.current_employee_index] if self.employee_names else "Default"
        self.class_win.title(f"Classifying: {current_emp}")

    def get_data(self):
        length_input = simpledialog.askinteger("Dictionary Size", "How many items do you have?", minvalue=1,
                                               parent=self.root)
        if not length_input:
            messagebox.showerror("Error", "No items provided.")
            return False

        self.target_dict = {}
        for i in range(length_input):
            key = simpledialog.askstring(title="What is the Next Item?", prompt="Enter Next task:", parent=self.root)
            if key is None: break
            value = simpledialog.askstring(title="Input", prompt=f"Enter value for '{key}':", parent=self.root)
            if value is None: break
            self.target_dict[key] = value

        return True

    def next_key(self):
        self.launch()
        try:
            self.current_key = next(self.keys_iterator)
            self.label_key.config(text=f"'{self.current_key}'\n(Value: {self.target_dict[self.current_key]})")
        except StopIteration:
            self.finish_employee_classification()

    def process_input(self, choice):
        if self.current_key:
            self.results[self.current_key] = choice
            self.next_key()

    def finish_employee_classification(self):
        """Saves current employee results and evaluates if there are more employees left."""
        current_emp = self.employee_names[self.current_employee_index]
        self.save(self.save_folder, current_emp)
        print(f"Saved schedule for {current_emp}")

        self.current_employee_index += 1
        if self.current_employee_index < len(self.employee_names):
            self.results = {k: 0 for k in self.target_dict.keys()}
            self.keys_iterator = iter(self.target_dict.keys())
            self.next_key()
        else:
            if self.class_win and self.class_win.winfo_exists():
                self.class_win.destroy()

            # Prevent overwriting standard master name files if we were only targeting one update loop
            if not self.is_updating_single:
                names_df = pd.DataFrame(self.employee_names, columns=['EmployeeName'])
                names_df.to_pickle(os.path.join(self.save_folder, "names.pickle"))
                messagebox.showinfo("Done!", "All employee schedules generated and saved successfully!")
            else:
                self.is_updating_single = False
                messagebox.showinfo("Done!", f"Schedule status for {current_emp} updated successfully!")

    def assign_schedule(self):
        if not self.get_data():
            return

        names, file_path = self.get_employee_data()
        if not names:
            return
        if not file_path:
            messagebox.showwarning("Warning", "No file name path given. Process aborted.")
            return

        self.is_updating_single = False
        self.employee_names = names
        self.current_employee_index = 0
        self.save_folder = os.path.dirname(file_path)

        self.results = {k: 0 for k in self.target_dict.keys()}
        self.keys_iterator = iter(self.target_dict.keys())

        self.next_key()

    def process_data(self, period):
        a = sum(self.results.values())
        total_tasks = len(self.results.keys())

        if a == total_tasks:
            print("% to do today: 0")
        elif a == 0:
            print("% to do today: " + str(1 / period * 100))
        else:
            remaining_tasks = total_tasks - a
            print("% to do today: " + str(remaining_tasks / total_tasks / period * 100))

    def update(self, folder, name):
        pickle_file = os.path.join(folder, f"{name}.pickle")
        if os.path.exists(pickle_file):
            self.load_data(pickle_file)
            self.next_key()
            self.save(folder, name)
        else:
            print(f"Schedule file for {name} not found.")

    def load_data(self, file_path):
        f = pd.read_pickle(file_path)
        self.results = {}
        self.target_dict = {}
        if 'results' in f and 'target_dict' in f:
            self.results = f['results'].to_dict()
            self.target_dict = f['target_dict'].to_dict()
        self.keys_iterator = iter(self.target_dict.keys())

    def save(self, folder, name):
        if not os.path.exists(folder):
            os.makedirs(folder)
        df = pd.DataFrame({'results': self.results, 'target_dict': self.target_dict})
        df.to_pickle(os.path.join(folder, f"{name}.pickle"))

    def get_employee_data(self):
        num_employees = simpledialog.askinteger("Employee Count", "How many employees do you have?", minvalue=1,
                                                parent=self.root)
        if not num_employees:
            messagebox.showinfo("Cancelled", "No employee count provided.")
            return None, None

        employee_list = []
        for i in range(num_employees):
            name = simpledialog.askstring("Employee Name", f"Enter the name for employee #{i + 1}:", parent=self.root)
            if name is None:
                messagebox.showwarning("Incomplete", "Process interrupted. Keeping partial list.")
                break
            employee_list.append(name.strip() if name.strip() else f"Employee_{i + 1}")

        file_path = filedialog.asksaveasfilename(
            title="Select File Location to Save Employees",
            parent=self.root,
            initialfile="employees.txt",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        return employee_list, file_path

    def check_on_schedule(self):
        """Pulls up an intermediate window offering Analysis, To-Do list views, or status updates."""
        choice_win = tk.Toplevel(self.root)
        choice_win.title("Employee Options")
        choice_win.geometry("480x140")  # Widened layout setup to naturally adapt 3 items

        lbl = tk.Label(choice_win, text="Choose an option for the employee:", font=("Arial", 11))
        lbl.pack(pady=15)

        btn_frame = tk.Frame(choice_win)
        btn_frame.pack(pady=5)

        # Run Analysis Button
        btn_analysis = tk.Button(btn_frame, text="Run analysis", width=14,
                                 command=lambda: [choice_win.destroy(), self.run_analysis()])
        btn_analysis.pack(side=tk.LEFT, padx=10)

        # Check To Do List Button
        btn_todo = tk.Button(btn_frame, text="Check to do list", width=14,
                             command=lambda: [choice_win.destroy(), self.check_todo_list()])
        btn_todo.pack(side=tk.LEFT, padx=10)

        # Update Status Button (NEW)
        btn_update = tk.Button(btn_frame, text="Update status", width=14,
                               command=lambda: [choice_win.destroy(), self.prompt_update_status()])
        btn_update.pack(side=tk.LEFT, padx=10)

    def run_analysis(self):
        """Displays metric performance in a pop-up window instead of the console."""
        file_path = filedialog.askopenfilename(
            title="Select the 'names.pickle' file to check schedules",
            parent=self.root,
            filetypes=[("Pickle Files", "*.pickle"), ("All Files", "*.*")]
        )
        if not file_path:
            return

        period = simpledialog.askinteger(
            "Schedule Period",
            "How many days are left in the schedule?",
            initialvalue=7,
            minvalue=1,
            parent=self.root
        )

        if not period:
            messagebox.showinfo("Cancelled", "Check on schedule aborted.")
            return

        folder_dir = os.path.dirname(file_path)
        try:
            names_data = pd.read_pickle(file_path)
            # Standardize name extraction
            if isinstance(names_data, pd.DataFrame):
                names = names_data['EmployeeName'].tolist() if 'EmployeeName' in names_data.columns else \
                names_data.iloc[:, 0].tolist()
            else:
                names = list(names_data)

            # Create the Analysis Display Window
            analysis_win = tk.Toplevel(self.root)
            analysis_win.title("Employee Performance Analysis")
            analysis_win.geometry("400x400")

            txt_display = scrolledtext.ScrolledText(analysis_win, wrap="word", font=("Courier New", 10))
            txt_display.pack(fill="both", expand=True, padx=10, pady=10)

            for name in names:
                pickle_file = os.path.join(folder_dir, f"{name}.pickle")
                if os.path.exists(pickle_file):
                    f = pd.read_pickle(pickle_file)
                    if 'results' in f and 'target_dict' in f:
                        self.results = f['results'].to_dict()
                        self.target_dict = f['target_dict'].to_dict()

                        # Calculate logic
                        a = sum(self.results.values())
                        total_tasks = len(self.results.keys())
                        percentage = 0
                        if a < total_tasks and a != 0:
                            percentage = (total_tasks - a) / total_tasks / period * 100
                        elif a == 0:
                            percentage = 1 / period * 100

                        txt_display.insert(tk.END, f"Employee: {name}\n")
                        txt_display.insert(tk.END, f"Tasks Remaining: {total_tasks - a}/{total_tasks}\n")
                        txt_display.insert(tk.END, f"% to do today: {percentage:.2f}%\n")
                        txt_display.insert(tk.END, "-" * 40 + "\n")
                    else:
                        txt_display.insert(tk.END, f"{name}: Data structure missing.\n" + "-" * 40 + "\n")
                else:
                    txt_display.insert(tk.END, f"{name}: Schedule file not found.\n" + "-" * 40 + "\n")

            txt_display.config(state="disabled")

        except Exception as e:
            messagebox.showerror("Error", f"Could not read schedules: {e}")
            
            
    def check_todo_list(self):
        """Loads names.pickle, opens individual employee files, and displays their details in a UI window."""
        file_path = filedialog.askopenfilename(
            title="Select the 'names.pickle' file to view lists",
            parent=self.root,
            filetypes=[("Pickle Files", "*.pickle"), ("All Files", "*.*")]
        )
        if not file_path:
            return

        folder_dir = os.path.dirname(file_path)
        try:
            names_data = pd.read_pickle(file_path)

            if isinstance(names_data, pd.DataFrame):
                if 'EmployeeName' in names_data.columns:
                    names = names_data['EmployeeName'].tolist()
                elif not names_data.empty:
                    names = names_data.iloc[:, 0].tolist()
                else:
                    names = names_data.index.tolist()
            elif isinstance(names_data, list):
                names = names_data
            else:
                names = list(names_data)

            if not names:
                raise ValueError("The selected file does not contain any readable employee names.")

            # Set up the Display Window for the Schedules
            todo_win = tk.Toplevel(self.root)
            todo_win.title("Employee Tasks and Schedules")
            todo_win.geometry("450x400")

            txt_display = scrolledtext.ScrolledText(todo_win, wrap="word", font=("Courier New", 10))
            txt_display.pack(fill="both", expand=True, padx=10, pady=10)

            for name in names:
                pickle_file = os.path.join(folder_dir, f"{name}.pickle")
                txt_display.insert(tk.END, f"=========================================\n")
                txt_display.insert(tk.END, f" EMPLOYEE: {name}\n")
                txt_display.insert(tk.END, f"=========================================\n")

                if os.path.exists(pickle_file):
                    f = pd.read_pickle(pickle_file)

                    if 'results' in f and 'target_dict' in f:
                        emp_results = f['results'].to_dict()
                        emp_targets = f['target_dict'].to_dict()

                        txt_display.insert(tk.END, f"{'Task Name':<25} | {'Value':<10} | {'Status':<10}\n")
                        txt_display.insert(tk.END, f"{'-' * 25}-|-{'-' * 10}-|-{'-' * 10}\n")

                        for task, value in emp_targets.items():
                            choice = emp_results.get(task, 0)
                            status_str = "Completed" if choice == 1 else "To-Do"
                            txt_display.insert(tk.END, f"{task:<25} | {str(value):<10} | {status_str:<10}\n")
                    else:
                        txt_display.insert(tk.END, "[Warning] Missing 'results' or 'target_dict' arrays.\n")
                else:
                    txt_display.insert(tk.END, "[File Not Found] No saved schedule pickle exists.\n")

                txt_display.insert(tk.END, "\n\n")

            txt_display.config(state="disabled")  # Set read-only

        except Exception as e:
            messagebox.showerror("Error", f"Could not read schedules: {e}")

    def prompt_update_status(self):
        """Loads names.pickle, lets user select exactly ONE employee, and executes their status updates."""
        file_path = filedialog.askopenfilename(
            title="Select 'names.pickle' to fetch current employee roster",
            parent=self.root,
            filetypes=[("Pickle Files", "*.pickle"), ("All Files", "*.*")]
        )
        if not file_path:
            return

        folder_dir = os.path.dirname(file_path)
        try:
            names_data = pd.read_pickle(file_path)
            if isinstance(names_data, pd.DataFrame):
                if 'EmployeeName' in names_data.columns:
                    names = names_data['EmployeeName'].tolist()
                elif not names_data.empty:
                    names = names_data.iloc[:, 0].tolist()
                else:
                    names = names_data.index.tolist()
            elif isinstance(names_data, list):
                names = names_data
            else:
                names = list(names_data)

            if not names:
                raise ValueError("No active names found in file.")

            # Create selector interface window frame
            select_win = tk.Toplevel(self.root)
            select_win.title("Select Employee to Update")
            select_win.geometry("320x280")

            lbl = tk.Label(select_win, text="Select single employee profile:", font=("Arial", 11))
            lbl.pack(pady=10)

            listbox = tk.Listbox(select_win, selectmode=tk.SINGLE)
            listbox.pack(fill="both", expand=True, padx=20, pady=5)
            for name in names:
                listbox.insert(tk.END, name)

            def on_confirm():
                selection = listbox.curselection()
                if not selection:
                    messagebox.showwarning("Warning", "Please select an employee profile.")
                    return

                selected_name = listbox.get(selection[0])
                select_win.destroy()

                pickle_file = os.path.join(folder_dir, f"{selected_name}.pickle")
                if os.path.exists(pickle_file):
                    self.is_updating_single = True
                    self.employee_names = [selected_name]
                    self.current_employee_index = 0
                    self.save_folder = folder_dir

                    self.load_data(pickle_file)
                    self.next_key()
                else:
                    messagebox.showerror("Error", f"Pickle file record not found for: {selected_name}")

            btn_confirm = tk.Button(select_win, text="Select Profile", command=on_confirm)
            btn_confirm.pack(pady=10)

        except Exception as e:
            messagebox.showerror("Error", f"Failed parsing tracking list: {e}")

    # --- Card Game Utility Blocks ---
    def get_cards(self):
        window_a = tk.Toplevel(self.root)
        window_a.title("Get Cards")
        window_a.geometry("300x200")
        g = self.generate_cards()
        for index, (key, value) in enumerate(g.items()):
            lbl_key = tk.Label(window_a, text=f"Player {key}:", font=("Arial", 10, 'bold'))
            lbl_key.grid(row=index, column=0, padx=10, pady=5, sticky="w")
            lbl_val = tk.Label(window_a, text=", ".join(value), font=("Arial", 10))
            lbl_val.grid(row=index, column=1, padx=10, pady=5, sticky="w")

    def generate_cards(self):
        suit = ('h', 'd', 'c', 's')
        cards = ('A', 'K', 'Q', 'J', '10', '9', '8', '7', '6', '5', '4', '3', '2')
        deck = {i: [i + ii for ii in cards] for i in suit}
        players = {i: [] for i in range(4)}
        for i in range(4):
            for ii in range(5):
                deck, s = self.get_card(deck, suit)
                players[i].append(s)
        return self.drop_card(players)

    def drop_card(self, players):
        for i in players:
            players[i].remove(random.choice(players[i]))
        return players

    def get_card(self, deck, suit):
        ss = random.choice([s for s in suit if deck[s]])
        c = random.choice(deck[ss])
        deck[ss].remove(c)
        return deck, c


if __name__ == "__main__":
    root = tk.Tk()
    app = Administrator(root)
    root.mainloop()
