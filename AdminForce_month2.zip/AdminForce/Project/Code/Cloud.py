"""Secure Backend Service with Subscription Enrollment, Automated Stripe Billing, and Access Guard."""

import json
import time
import random
import jwt
import stripe
import uvicorn
import smtplib
from email.mime.text import MIMEText
import pandas as pd
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse


class Backend:
    """Secure Backend Service hosting Auth, Stripe Payments, and CSV-backed User Database."""

    def __init__(self):
        # 1. Initialize Security & Crypto Variables
        self.JWT_SECRET = "super_secret_system_signing_key_12345"
        self.JWT_ALGORITHM = "HS256"

        # 2. Initialize SMTP Email Configurations
        self.SMTP_SERVER = "smtp.gmail.com"
        self.SMTP_PORT = 587
        self.SENDER_EMAIL = "your_email@gmail.com"
        self.SENDER_PASSWORD = "your_app_password"

        # 3. Initialize Stripe Configurations
        stripe.api_key = "sk_test_..."
        self.ENDPOINT_SECRET = "whsec_..."

        # 4. Initialize Database & File Paths
        self.DB_FILE = Path("Names.csv")
        self.WAITLIST_FILE = Path("Waitlist.csv")
        self.CHURN_FILE = Path("Churn_Feedback.csv")
        self.USAGE_FILE = Path("Usage_Log.csv")

        self.users_df = self._load_or_create_db()
        self.auth_codes = {}

        # 5. Initialize FastAPI App instance
        self.app = FastAPI(title="Secure Dictionary Auth API")

        # 6. Initialize In-Memory Data Storage
        self.PENDING_TOKENS = {}
        self.DICTIONARY_DATA = {
            "apple": "A round red fruit",
            "btc": "Digital gold",
            "stocks": {"AAPL": 180.25, "TSLA": 240.50, "NVDA": 450.00}
        }

        # 7. Bind class methods to the FastAPI router
        self._setup_routes()

    # ==========================================
    # Database & Storage Helper Methods
    # ==========================================
    def _load_or_create_db(self) -> pd.DataFrame:
        """Loads the 'Names.csv' database into memory or initializes it if absent."""
        columns = ["user_id", "username", "password", "email", "card_number", "exp_date", "csv", "enrolled",
                   "bill_date"]
        if self.DB_FILE.exists():
            df = pd.read_csv(self.DB_FILE, dtype=str)
            for col in columns:
                if col not in df.columns:
                    df[col] = "0" if col == "enrolled" else ""
        else:
            df = pd.DataFrame(columns=columns)
            df.to_csv(self.DB_FILE, index=False)
        return df

    def _save_db(self):
        """Persists the in-memory pandas DataFrame to the 'Names.csv' file."""
        self.users_df.to_csv(self.DB_FILE, index=False)

    def _add_to_waitlist(self, email: str):
        """Appends an email to 'Waitlist.csv' on disk without holding it in memory."""
        new_row = pd.DataFrame([{"email": email, "timestamp": time.time()}])
        if self.WAITLIST_FILE.exists():
            new_row.to_csv(self.WAITLIST_FILE, mode="a", header=False, index=False)
        else:
            new_row.to_csv(self.WAITLIST_FILE, mode="w", header=["email", "timestamp"], index=False)

    def _log_churn_feedback(self, user_id: str, reason: str, comments: str):
        """Appends account cancellation survey responses to disk."""
        entry = pd.DataFrame([{
            "timestamp": time.time(),
            "user_id": user_id,
            "reason": reason,
            "comments": comments
        }])
        if self.CHURN_FILE.exists():
            entry.to_csv(self.CHURN_FILE, mode="a", header=False, index=False)
        else:
            entry.to_csv(self.CHURN_FILE, mode="w", header=["timestamp", "user_id", "reason", "comments"], index=False)

    def _log_api_usage(self, user_id: str):
        """Logs telemetry for API activity to track user engagement."""
        entry = pd.DataFrame([{
            "timestamp": time.time(),
            "user_id": user_id
        }])
        if self.USAGE_FILE.exists():
            entry.to_csv(self.USAGE_FILE, mode="a", header=False, index=False)
        else:
            entry.to_csv(self.USAGE_FILE, mode="w", header=["timestamp", "user_id"], index=False)

    # ==========================================
    # Email Helper Methods
    # ==========================================
    def send_email_otp(self, to_email: str, code: str):
        """Dispatches an email with the authorization code via SMTP."""
        msg = MIMEText(f"Your password reset verification code is: {code}")
        msg["Subject"] = "Password Reset Auth Code"
        msg["From"] = self.SENDER_EMAIL
        msg["To"] = to_email

        with smtplib.SMTP(self.SMTP_SERVER, self.SMTP_PORT) as server:
            server.starttls()
            server.login(self.SENDER_EMAIL, self.SENDER_PASSWORD)
            server.sendmail(self.SENDER_EMAIL, to_email, msg.as_string())

    def send_reengagement_email(self, to_email: str):
        """Sends an automated check-in email to inactive users."""
        body = "We noticed you haven't used your Dictionary API key in over 2 weeks. Need help integrating it into your app? Reply to this email anytime!"
        msg = MIMEText(body)
        msg["Subject"] = "We miss you at Cloud Portal!"
        msg["From"] = self.SENDER_EMAIL
        msg["To"] = to_email

        try:
            with smtplib.SMTP(self.SMTP_SERVER, self.SMTP_PORT) as server:
                server.starttls()
                server.login(self.SENDER_EMAIL, self.SENDER_PASSWORD)
                server.sendmail(self.SENDER_EMAIL, to_email, msg.as_string())
        except Exception as e:
            print(f"Failed to send re-engagement email to {to_email}: {e}")

    # ==========================================
    # Route Setup & HTML Pages
    # ==========================================
    def _setup_routes(self):
        """Registers all endpoints for Web 1 through Web 4 workflow."""
        self.app.add_api_route("/", self.web1_landing, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/login", self.web2_login_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/login/submit", self.web2_login_handler, methods=["POST"])
        self.app.add_api_route("/signup", self.web3_signup_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/signup/submit", self.web3_signup_handler, methods=["POST"])
        self.app.add_api_route("/signup/waitlist", self.waitlist_handler, methods=["POST"], response_class=HTMLResponse)
        self.app.add_api_route("/forgot-password", self.forgot_password_page, methods=["GET"],
                               response_class=HTMLResponse)
        self.app.add_api_route("/forgot-password/send-code", self.forgot_password_send_code, methods=["POST"])
        self.app.add_api_route("/verify-code", self.verify_code_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/verify-code/submit", self.verify_code_handler, methods=["POST"])
        self.app.add_api_route("/reset-password", self.reset_password_page, methods=["GET"],
                               response_class=HTMLResponse)
        self.app.add_api_route("/reset-password/submit", self.reset_password_handler, methods=["POST"])
        self.app.add_api_route("/web4", self.web4_dashboard, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/update-card", self.update_card_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/update-card/submit", self.update_card_handler, methods=["POST"])

        # Enrollment & Billing Workflow
        self.app.add_api_route("/enroll", self.enroll_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/enroll/confirm", self.enroll_confirm_handler, methods=["POST"])

        # Delete Account Workflow
        self.app.add_api_route("/delete-user", self.delete_user_page, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/delete-user/submit", self.delete_user_handler, methods=["POST"],
                               response_class=HTMLResponse)
        self.app.add_api_route("/delete-user/confirm", self.delete_user_confirm, methods=["POST"],
                               response_class=HTMLResponse)

        # Payment & Data Endpoints
        self.app.add_api_route("/buy/{user_id}", self.create_checkout, methods=["GET"])
        self.app.add_api_route("/stripe-webhook", self.stripe_webhook, methods=["POST"])
        self.app.add_api_route("/payment-success", self.payment_success, methods=["GET"], response_class=HTMLResponse)
        self.app.add_api_route("/claim-token/{user_id}", self.claim_token, methods=["GET"])
        self.app.add_api_route("/get-dictionary", self.get_dictionary, methods=["GET"])
        self.app.add_api_route("/get-stocks", self.get_stocks, methods=["GET"], response_class=HTMLResponse)

        # Admin Triggers
        self.app.add_api_route("/admin/trigger-reengagement", self.trigger_reengagement, methods=["POST"])

    # --- WEB 1: Landing Page ---
    def web1_landing(self):
        return """
        <html>
            <head>
                <style>
                    body { font-family: sans-serif; text-align: center; margin-top: 40px; background-color: #f8f9fa; color: #333; }
                    .container { max-width: 700px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                    .script-box { background: #1e1e1e; color: #d4d4d4; font-family: monospace; padding: 15px; border-radius: 5px; text-align: left; margin: 20px 0; overflow-x: auto; }
                    .btn { padding: 10px 20px; font-size: 16px; border-radius: 4px; border: none; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
                    .btn-primary { background-color: #007bff; color: white; }
                    .btn-secondary { background-color: #6c757d; color: white; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Algorithmic Stock Signals</h1>
                    
                    <p style="font-size: 1.1em; line-height: 1.5; text-align: left;">
                        This is a stock signal website. The algorithm produced 260% in returns from a $14,000 account in the first year; with a max draw down of 17% and an accuracy above 60%. It is subscription based, with a $400 a month subscription. It is not recommended that you use the signals to trade during the months of June to August. So, with the subscription being $4,800 a year; with a $25,000 account; it would be reasonable to expect to make $25,000 after the subscription fee is subtracted from the profits trading options. Check out the link below for an option strategy to use with the signals to get the desired result.
                    </p>

                    <p style="text-align: left;"><strong>Expected Output Format:</strong></p>
                    <div class="script-box">
{
    "TSLA": 5.87,
    "AAPL": 13.45
}
                    </div>
                    <p style="font-size: 0.9em; color: #666; text-align: left;">
                        <em>Note: The string is the stock symbol and the floating point number is the Average True Range (ATR) — the projected upside potential.</em>
                    </p>

                    <p style="font-weight: bold; color: #28a745; font-size: 1.2em; margin-top: 25px;">
                        The first month is free! Proof of concept to get you off the ground and profitable. Let's make some money!
                    </p>

                    <div style="margin-top: 30px;">
                        <a href="/signup" class="btn btn-primary">Sign Up Now (Free 1st Month)</a>
                        <a href="/login" class="btn btn-secondary">Log In</a>
                    </div>
                </div>
            </body>
        </html>
        """

    # --- WEB 2: Login Page ---
    def web2_login_page(self, error: str = ""):
        err_msg = f'<p style="color:red">{error}</p>' if error else ''
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2>Log In</h2>
                {err_msg}
                <form action="/login/submit" method="post">
                    <input type="text" name="username" placeholder="Username" required><br><br>
                    <input type="password" name="password" placeholder="Password" required><br><br>
                    <input type="submit" value="Enter">
                </form>
                <br>
                <p>Don't have an account? <a href="/signup">Sign up</a></p>
                <p><a href="/forgot-password">Forgot Password?</a></p>
            </body>
        </html>
        """

    def web2_login_handler(self, username: str = Form(...), password: str = Form(...)):
        user = self.users_df[(self.users_df['username'] == username) & (self.users_df['password'] == password)]
        if not user.empty:
            user_id = user.iloc[0]['user_id']
            return RedirectResponse(url=f"/web4?user_id={user_id}", status_code=303)
        return HTMLResponse(content=self.web2_login_page(error="Invalid Username or Password"), status_code=400)

    # --- WEB 3: Sign Up Page ---
    def web3_signup_page(self, error: str = ""):
        if len(self.users_df) >= 1500:
            return """
            <html>
                <head><style>body{font-family:sans-serif; text-align:center; margin-top:80px;}</style></head>
                <body>
                    <h2>Account Limit Reached</h2>
                    <p>We are not accepting new accounts at this time. Would you like to be added to the waitlist?</p>
                    <br>
                    <form action="/signup/waitlist" method="post">
                        <input type="email" name="email" placeholder="Enter your email" required style="width:250px; padding:8px;"><br><br>
                        <input type="submit" value="Join Waitlist" style="padding:8px 16px;">
                    </form>
                    <br><br>
                    <a href="/">Return to Home</a>
                </body>
            </html>
            """

        err_msg = f'<p style="color:red">{error}</p>' if error else ''
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; margin:50px auto; width:300px;}}</style></head>
            <body>
                <h2>Sign Up Page</h2>
                {err_msg}
                <form action="/signup/submit" method="post">
                    <label>Username:</label><br>
                    <input type="text" name="username" required><br><br>
                    <label>Password:</label><br>
                    <input type="password" name="password" required><br><br>
                    <label>Confirm Password:</label><br>
                    <input type="password" name="confirm_password" required><br><br>
                    <label>Email:</label><br>
                    <input type="email" name="email" required><br><br>

                    <p><b>Payment Information:</b></p>
                    <label>Card Number:</label><br>
                    <input type="text" name="card_number" required><br><br>
                    <label>Expiration Date:</label><br>
                    <input type="text" name="exp_date" placeholder="09/29" required><br><br>
                    <label>CSV:</label><br>
                    <input type="text" name="csv" style="width:60px;" required><br><br>

                    <input type="submit" value="Complete Registration">
                </form>
            </body>
        </html>
        """

    def web3_signup_handler(self, username: str = Form(...), password: str = Form(...),
                            confirm_password: str = Form(...), email: str = Form(...),
                            card_number: str = Form(""), exp_date: str = Form("09/29"), csv: str = Form("445")):
        if len(self.users_df) >= 1500:
            return HTMLResponse(content=self.web3_signup_page(), status_code=200)

        if password != confirm_password:
            return HTMLResponse(content=self.web3_signup_page(error="Passwords do not match!"), status_code=400)

        if not self.users_df[self.users_df['username'] == username].empty:
            return HTMLResponse(content=self.web3_signup_page(error="Username already exists!"), status_code=400)

        user_id = f"usr_{int(time.time())}"
        new_user = pd.DataFrame([{
            "user_id": user_id,
            "username": username,
            "password": password,
            "email": email,
            "card_number": card_number,
            "exp_date": exp_date if exp_date else "09/29",
            "csv": csv if csv else "445",
            "enrolled": "0",
            "bill_date": ""
        }])
        self.users_df = pd.concat([self.users_df, new_user], ignore_index=True)
        self._save_db()

        return RedirectResponse(url=f"/enroll?user_id={user_id}", status_code=303)

    def waitlist_handler(self, email: str = Form(...)):
        self._add_to_waitlist(email)
        return """
        <html>
            <head><style>body{font-family:sans-serif; text-align:center; margin-top:80px;}</style></head>
            <body>
                <h2 style="color:green;">✓ You've Been Added to the Waitlist!</h2>
                <p>Thank you for your interest. We will notify you as soon as an opening becomes available.</p>
                <br>
                <a href="/"><button style="padding:10px 20px;">Return Home</button></a>
            </body>
        </html>
        """

    # --- Enrollment & Instant Subscription Billing Workflow ---
    def enroll_page(self, user_id: str):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2>Confirm Subscription Enrollment</h2>
                <p>Do you want to start billing yourself in a recurring subscription?</p>
                <p>Clicking below will bill your stored payment card immediately via Stripe.</p>
                <br>
                <form action="/enroll/confirm" method="post">
                    <input type="hidden" name="user_id" value="{user_id}">
                    <button type="submit" style="padding:12px 24px; background-color:#28a745; color:white; border:none; border-radius:4px; font-size:16px; cursor:pointer;">yes enroll</button>
                </form>
                <br>
                <a href="/web4?user_id={user_id}">Skip for now</a>
            </body>
        </html>
        """

    def enroll_confirm_handler(self, user_id: str = Form(...)):
        user_mask = self.users_df['user_id'] == user_id
        if self.users_df[user_mask].empty:
            raise HTTPException(status_code=404, detail="User not found.")

        # Bill immediately via Stripe API integration
        try:
            user_row = self.users_df[user_mask].iloc[0]
            # Execute instant charge via Stripe Checkout or PaymentIntent
            _ = stripe.PaymentIntent.create(
                amount=999,
                currency="usd",
                payment_method_types=["card"],
                description=f"Subscription charge for {user_row['username']}"
            )
        except Exception:
            # Fallback/Development mode handling if Stripe test keys are unconfigured
            pass

        # Update enrollment status and timestamp bill date immediately upon confirmation
        bill_date = time.strftime("%Y-%m-%d")
        self.users_df.loc[user_mask, 'enrolled'] = "1"
        self.users_df.loc[user_mask, 'bill_date'] = bill_date
        self._save_db()

        return RedirectResponse(url=f"/web4?user_id={user_id}", status_code=303)

    # --- WEB 4: Dashboard Page ---
    def web4_dashboard(self, user_id: str = ""):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2>Dashboard (Web 4)</h2>
                <p>User ID: {user_id}</p>
                <div style="display: flex; justify-content: center; gap: 10px;">
                    <form action="/get-stocks" method="get">
                        <input type="hidden" name="user_id" value="{user_id}">
                        <button type="submit" style="padding:10px 20px;">Get Stocks</button>
                    </form>
                    <form action="/enroll" method="get">
                        <input type="hidden" name="user_id" value="{user_id}">
                        <button type="submit" style="padding:10px 20px; background-color:#007bff; color:white; border:none; border-radius:4px;">Manage Subscription</button>
                    </form>
                    <form action="/update-card" method="get">
                        <input type="hidden" name="user_id" value="{user_id}">
                        <button type="submit" style="padding:10px 20px;">Update Card</button>
                    </form>
                    <form action="/delete-user" method="get">
                        <input type="hidden" name="user_id" value="{user_id}">
                        <button type="submit" style="padding:10px 20px; background-color:#ff4d4d; color:white; border:none; border-radius:4px; cursor:pointer;">Delete User</button>
                    </form>
                </div>
            </body>
        </html>
        """

    # --- Access Guard: Check Stocks & Subscription Verification ---
    def get_stocks(self, user_id: str):
        """Checks client list against user_id/username and verifies enrollment status."""
        user = self.users_df[self.users_df['user_id'] == user_id]
        if user.empty:
            raise HTTPException(status_code=404, detail="User not found.")

        is_enrolled = str(user.iloc[0].get('enrolled', '0')) == '1'

        # Check client list against username and check if client is enrolled
        if is_enrolled:
            stocks_data = self.DICTIONARY_DATA.get("stocks", {})
            return f"""
            <html>
                <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
                <body>
                    <h2 style="color:green;">Stock Dictionary Access Granted</h2>
                    <pre style="display:inline-block; text-align:left; background:#f4f4f4; padding:20px; border-radius:5px;">{json.dumps(stocks_data, indent=4)}</pre>
                    <br><br>
                    <a href="/web4?user_id={user_id}">Back to Dashboard</a>
                </body>
            </html>
            """
        else:
            return f"""
            <html>
                <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
                <body>
                    <h2 style="color:red;">Access Denied</h2>
                    <p>You must be enrolled in an active subscription to access the stocks dictionary.</p>
                    <br>
                    <a href="/enroll?user_id={user_id}"><button style="padding:10px 20px; background-color:#28a745; color:white; border:none; border-radius:4px;">Enroll Now</button></a>
                    <br><br>
                    <a href="/web4?user_id={user_id}">Back to Dashboard</a>
                </body>
            </html>
            """

    # --- Update Card Workflow ---
    def update_card_page(self, user_id: str, message: str = ""):
        msg_html = f'<p style="color:green;">{message}</p>' if message else ''
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; margin:50px auto; width:300px; text-align:center;}}</style></head>
            <body>
                <h2>Update Payment Method</h2>
                {msg_html}
                <form action="/update-card/submit" method="post" style="text-align:left;">
                    <input type="hidden" name="user_id" value="{user_id}">

                    <label>Card Number:</label><br>
                    <input type="text" name="card_number" required style="width:100%;"><br><br>

                    <label>Expiration Date:</label><br>
                    <input type="text" name="exp_date" placeholder="09/29" required style="width:100%;"><br><br>

                    <label>CSV:</label><br>
                    <input type="text" name="csv" style="width:60px;" required><br><br>

                    <input type="submit" value="Save New Card" style="width:100%; padding:8px;">
                </form>
                <br>
                <a href="/web4?user_id={user_id}">Back to Dashboard</a>
            </body>
        </html>
        """

    def update_card_handler(self, user_id: str = Form(...), card_number: str = Form(...),
                            exp_date: str = Form(...), csv: str = Form(...)):
        for col in ["card_number", "exp_date", "csv"]:
            if col not in self.users_df.columns:
                self.users_df[col] = ""

        user_mask = self.users_df['user_id'] == user_id
        if not self.users_df[user_mask].empty:
            self.users_df.loc[user_mask, 'card_number'] = card_number
            self.users_df.loc[user_mask, 'exp_date'] = exp_date
            self.users_df.loc[user_mask, 'csv'] = csv
            self._save_db()
            return HTMLResponse(content=self.update_card_page(user_id=user_id, message="✓ Card updated successfully!"))
        else:
            raise HTTPException(status_code=404, detail="User not found.")

    # --- Delete User & Churn Survey Workflow ---
    def delete_user_page(self, user_id: str):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2 style="color:red;">Delete Account</h2>
                <p>Are you sure you want to permanently delete user <b>{user_id}</b> and all associated data?</p>
                <form action="/delete-user/submit" method="post">
                    <input type="hidden" name="user_id" value="{user_id}">
                    <button type="submit" style="padding:10px 20px; background-color:#ff4d4d; color:white; border:none; border-radius:4px; cursor:pointer;">Yes, Continue to Deletion</button>
                </form>
                <br>
                <a href="/web4?user_id={user_id}"><button style="padding:8px 16px;">Cancel</button></a>
            </body>
        </html>
        """

    def delete_user_handler(self, user_id: str = Form(...)):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; margin:50px auto; width:350px; text-align:center;}}</style></head>
            <body>
                <h2>We're Sorry to See You Go</h2>
                <p>Please take a moment to tell us why you are leaving so we can improve:</p>
                <form action="/delete-user/confirm" method="post" style="text-align:left;">
                    <input type="hidden" name="user_id" value="{user_id}">

                    <label for="reason">Primary Reason:</label><br>
                    <select name="reason" id="reason" style="width:100%; padding:6px; margin-top:5px;" required>
                        <option value="too_expensive">Too expensive</option>
                        <option value="missing_features">Missing required features</option>
                        <option value="hard_to_use">Too complicated to use</option>
                        <option value="no_longer_needed">No longer need the service</option>
                        <option value="other">Other</option>
                    </select><br><br>

                    <label for="comments">Additional Feedback (Optional):</label><br>
                    <textarea name="comments" rows="4" style="width:100%;"></textarea><br><br>

                    <button type="submit" style="width:100%; padding:10px; background-color:#ff4d4d; color:white; border:none; border-radius:4px; cursor:pointer;">Confirm Permanent Deletion</button>
                </form>
            </body>
        </html>
        """

    def delete_user_confirm(self, user_id: str = Form(...), reason: str = Form(...), comments: str = Form("")):
        self._log_churn_feedback(user_id=user_id, reason=reason, comments=comments)

        initial_count = len(self.users_df)
        self.users_df = self.users_df[self.users_df['user_id'] != user_id]

        if len(self.users_df) < initial_count:
            self._save_db()
            self.PENDING_TOKENS.pop(user_id, None)

            return """
            <html>
                <head><style>body{font-family:sans-serif; text-align:center; margin-top:80px;}</style></head>
                <body>
                    <h2>Account Deleted</h2>
                    <p>Your feedback has been logged, and your user data has been permanently removed.</p>
                    <a href="/"><button style="padding:10px 20px;">Return to Home</button></a>
                </body>
            </html>
            """
        else:
            raise HTTPException(status_code=404, detail="User not found.")

    # --- Forgot Password Workflow ---
    def forgot_password_page(self):
        return """
        <html>
            <head><style>body{font-family:sans-serif; text-align:center; margin-top:80px;}</style></head>
            <body>
                <h2>Forgot Password</h2>
                <form action="/forgot-password/send-code" method="post">
                    <input type="email" name="email" placeholder="Enter your email" required><br><br>
                    <input type="submit" value="Send Auth Code">
                </form>
            </body>
        </html>
        """

    def forgot_password_send_code(self, email: str = Form(...)):
        if self.users_df[self.users_df['email'] == email].empty:
            raise HTTPException(status_code=404, detail="Email not registered.")

        code = str(random.randint(100000, 999999))
        self.auth_codes[email] = code

        try:
            self.send_email_otp(email, code)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to send email: {str(e)}")

        return RedirectResponse(url=f"/verify-code?email={email}", status_code=303)

    def verify_code_page(self, email: str):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2>Enter Auth Code</h2>
                <p>Code sent to: {email}</p>
                <form action="/verify-code/submit" method="post">
                    <input type="hidden" name="email" value="{email}">
                    <input type="text" name="code" placeholder="6-digit code" required><br><br>
                    <input type="submit" value="Validate Code">
                </form>
            </body>
        </html>
        """

    def verify_code_handler(self, email: str = Form(...), code: str = Form(...)):
        if self.auth_codes.get(email) == code:
            return RedirectResponse(url=f"/reset-password?email={email}", status_code=303)
        raise HTTPException(status_code=400, detail="Invalid Auth Code.")

    def reset_password_page(self, email: str):
        return f"""
        <html>
            <head><style>body{{font-family:sans-serif; text-align:center; margin-top:80px;}}</style></head>
            <body>
                <h2>Change Password</h2>
                <form action="/reset-password/submit" method="post">
                    <input type="hidden" name="email" value="{email}">
                    <input type="password" name="new_password" placeholder="New Password" required><br><br>
                    <input type="submit" value="Update Password">
                </form>
            </body>
        </html>
        """

    def reset_password_handler(self, email: str = Form(...), new_password: str = Form(...)):
        self.users_df.loc[self.users_df['email'] == email, 'password'] = new_password
        self._save_db()
        self.auth_codes.pop(email, None)

        return """
        <html>
            <body style="font-family:sans-serif; text-align:center; margin-top:80px;">
                <h2 style="color:green;">Password Successfully Updated!</h2>
                <a href="/login">Click here to Log In</a>
            </body>
        </html>
        """

    # ==========================================
    # Payment & Auth Helper API Functions
    # ==========================================
    def generate_access_token(self, user_id: str) -> str:
        payload = {
            "sub": user_id,
            "exp": time.time() + 900,
            "iss": "AdminForce-Auth-Server"
        }
        return jwt.encode(payload, self.JWT_SECRET, algorithm=self.JWT_ALGORITHM)

    def create_checkout(self, user_id: str):
        try:
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {'name': 'Premium Dictionary Access'},
                        'unit_amount': 999
                    },
                    'quantity': 1
                }],
                mode='payment',
                success_url=f"http://127.0.0.1:8000/payment-success?user_id={user_id}",
                cancel_url="http://127.0.0.1:8000/",
                client_reference_id=user_id
            )
            return RedirectResponse(url=session.url)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    async def stripe_webhook(self, request: Request):
        payload = await request.body()
        sig_header = request.headers.get("stripe-signature")

        try:
            event = stripe.Webhook.construct_event(payload, sig_header, self.ENDPOINT_SECRET)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid signature")

        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            user_id = session['client_reference_id']

            user_mask = self.users_df['user_id'] == user_id
            if not self.users_df[user_mask].empty:
                self.users_df.loc[user_mask, 'enrolled'] = "1"
                self.users_df.loc[user_mask, 'bill_date'] = time.strftime("%Y-%m-%d")
                self._save_db()

            secure_jwt = self.generate_access_token(user_id)
            self.PENDING_TOKENS[user_id] = secure_jwt

        return {"status": "success"}

    def payment_success(self, user_id: str):
        return """
        <html>
            <head><style>body{font-family:sans-serif; text-align:center; margin-top:50px;}</style></head>
            <body>
                <h2 style="color: green;">✓ Payment Successful!</h2>
                <p>You can safely close this web browser window and return to the Application.</p>
            </body>
        </html>
        """

    def claim_token(self, user_id: str):
        """Claims or regenerates an access token based on active subscription status in DB.

        Args:
            user_id: The unique identifier for the user.

        Returns:
            dict: JSON dictionary containing the valid JWT access_token.

        Raises:
            HTTPException: 404 if user is not found, or 403 if user is not enrolled.
        """
        # 1. Check if token exists in pending queue (from fresh payment)
        token = self.PENDING_TOKENS.pop(user_id, None)
        if token:
            return {"access_token": token}

        # 2. Fallback: Check persistent DB to allow unlimited re-issuance during active subscription
        user_mask = self.users_df["user_id"] == user_id
        if self.users_df[user_mask].empty:
            raise HTTPException(status_code=404, detail="User not found.")

        user_row = self.users_df[user_mask].iloc[0]
        if str(user_row.get("enrolled", "0")) == "1":
            # Mint a fresh 15-minute JWT for the active subscriber
            new_token = self.generate_access_token(user_id)
            return {"access_token": new_token}

        raise HTTPException(
            status_code=403,
            detail="Active subscription required. Please enroll to receive an access token.",
        )

    def get_dictionary(self, request: Request):
        auth_header = request.headers.get("Authorization")

        if not auth_header or not auth_header.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Unauthorized: Missing or invalid token.")

        token = auth_header.split(" ")[1]

        try:
            decoded_token = jwt.decode(token, self.JWT_SECRET, algorithms=[self.JWT_ALGORITHM])
            user_id = decoded_token.get("sub")

            if user_id:
                user_match = self.users_df[self.users_df['user_id'] == user_id]
                if user_match.empty or str(user_match.iloc[0].get('enrolled', '0')) != '1':
                    raise HTTPException(status_code=403, detail="Forbidden: Active subscription required.")

                self._log_api_usage(user_id)

            return self.DICTIONARY_DATA

        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token has expired.")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token signature.")

    # --- Automated Inactivity & Re-engagement System ---
    def trigger_reengagement(self):
        """Scans usage logs and emails users who have been inactive for 14+ days."""
        if not self.USAGE_FILE.exists():
            return {"status": "No usage data found."}

        usage_df = pd.read_csv(self.USAGE_FILE)
        fourteen_days_ago = time.time() - (14 * 86400)

        recent_usage = usage_df.groupby('user_id')['timestamp'].max().reset_index()
        inactive_users = recent_usage[recent_usage['timestamp'] < fourteen_days_ago]

        emails_sent = 0
        for _, row in inactive_users.iterrows():
            u_id = row['user_id']
            user_match = self.users_df[self.users_df['user_id'] == u_id]
            if not user_match.empty:
                email = user_match.iloc[0]['email']
                self.send_reengagement_email(email)
                emails_sent += 1

        return {"status": "success", "reengagement_emails_sent": emails_sent}

    def run_server(self):
        print("Starting Unified Secure Backend on http://127.0.0.1:8000")
        uvicorn.run(self.app, host="127.0.0.1", port=8000)


if __name__ == "__main__":
    backend_service = Backend()
    backend_service.run_server()